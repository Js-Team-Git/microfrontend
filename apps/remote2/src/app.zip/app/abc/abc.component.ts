import { Component } from '@angular/core';

@Component({
  selector: 'microfrontend-abc',
  templateUrl: './abc.component.html',
  styleUrls: ['./abc.component.css'],
})
export class AbcComponent {}
